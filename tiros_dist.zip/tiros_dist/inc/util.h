/**\file Header for utility functions */
#ifndef __UTIL_H_
#define __UTIL_H_

#include <stdint.h>



/** This has to be implemented to be able to use any stdio functions
 * */
#ifndef putchar
#ifdef _cplusplus
extern "C" int putchar(int c);
#else
int putchar(int c);
#endif
#endif


void delayus(unsigned int d);
void delayms(unsigned int d);
/*lint -esym(522,delayus, delayms) The delay functions have hidden
 * side-effects (waiting) */

void puthexint(uint32_t val, int intsize);
void puthexchar(unsigned char c);

void puthexshort(unsigned short c);


/** @brief  This function writes a NULL terminated 'string' to the USART output
 *    queue, returning a pointer to the next character to be written.
 * @param s  address of the string
 */
void putstring(const char *s);

/** Print hex bytes separated by spaces */
void printbytesinhex(unsigned char const *bytes, int len);

#endif
