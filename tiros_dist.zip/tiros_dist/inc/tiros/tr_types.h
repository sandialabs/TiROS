/** @file
 * @brief  TiROS default values */
#ifndef _TiROS_TYPES_H_
#define _TiROS_TYPES_H_

/* Author: Ratish J. Punnoose, 2006
 * This file is part of TiROS, the Tickless Real-Time Operating System.
 * Copyright(c) 2006, 2007: Ratish J. Punnoose.
 * Copyright(c) 2006 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
 * certain rights in this software. 
 * 
 * TiROS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 or (at your option) any later version.
 *
 * TiROS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with TiROS; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
 *
 * As a special exception, if other files instantiate templates or use macros
 * or inline functions from this file, or you compile this file and link it
 * with other works to produce a work based on this file, this file does not
 * by itself cause the resulting work to be covered by the GNU General Public
 * License. However the source code for this file must still be made available
 * in accordance with section (3) of the GNU General Public License.
 *
 * This exception does not invalidate any other reasons why a work based on
 * this file might be covered by the GNU General Public License.
 *
 */
 


#include "tr_port.h"


#ifndef TIROS_C90_COMPATIBLE
#  define TIROS_C90_COMPATIBLE 0
#endif

#ifndef TIROS_MAX_ISR_NESTING  
#  define TIROS_MAX_ISR_NESTING  1
#endif


#ifndef TIROS_MAX_MUTEXES
/* This should not be more than 255 */
#  define TIROS_MAX_MUTEXES      255
#endif

#if (TIROS_MAX_MUTEXES > 255)
#  error "TIROS_MAX_MUTEXES must be less than 255"
#endif



#ifndef TIROS_ENABLE_MUTEX
#  define TIROS_ENABLE_MUTEX	1
#endif

#ifndef TIROS_ALLOW_SLEEP_W_MUTEX 
#  define TIROS_ALLOW_SLEEP_W_MUTEX 0
#endif

#ifndef TIROS_ENABLE_CSEM
#  define TIROS_ENABLE_CSEM	1
#endif

#ifndef TIROS_ENABLE_MSGQ
#  define TIROS_ENABLE_MSGQ	1
#endif

#ifndef TIROS_ENABLE_EFLAG
#  define TIROS_ENABLE_EFLAG	1
#endif


/** If no priority sort scheduler selection is made, select the
    default. */
#ifndef TIROS_PRIO_SORT_METHOD
#  define TIROS_PRIO_SORT_METHOD  1
#endif

/** This can be overridden to increase the number of supported tasks
 *   beyond 255 */
#ifndef TIROS_PORT_DEFINED_PID_T
typedef uint8_t  tid_t;
#endif




#if (TIROS_PRIO_SORT_METHOD == 1)
/** For the default scheduler, the process list is maintained by
 *  keeping the head of the list */
typedef tid_t plist_t;
#else
#  error "TIROS_PRIO_SORT has illegal value in configuration."
#endif





/** Mutex structure */
typedef /*@abstract@*/ struct mutex {
	plist_t waitlist;
	tid_t owner;
	tid_t prio_ceiling;
	uint8_t recursion;
} mutex_t;




#ifndef TIROS_USER_DEFINED_CSEMVAL_T
/* A custom type can be defined for csemval_t. Also CSEMVAL_MAX must
 * be defined along with it.  Note that csemval_t must be a signed
 * integer type. */
typedef int8_t csemval_t;
#endif

#ifndef TIROS_CSEMVAL_MAX
#  define TIROS_CSEMVAL_MAX 127
#endif


/** Counting semaphore structure */
typedef /*@abstract@*/ struct csem {
	plist_t waitlist;
	csemval_t count;
	csemval_t max_count;
} csem_t;



#ifndef TIROS_USER_DEFINED_MQ_T
/* A custom type for the message queue indexing can be specified by
 * the user.  This will allow for message queues greater than the
 * default.   */
typedef tid_t  mqind_t;
#endif


/** Message queue structure */
typedef /*@abstract@*/ struct msgQ {
	plist_t waitlist;
	mqind_t head;
	mqind_t currlen;
	mqind_t maxlen;

#if (TIROS_C90_COMPATIBLE == 1)
	/* C standard C90, ISO C++ does not support zero-length, or 
	 * variable length arrays. */
	osptr_t msgs[1];
#else 
	/* In GCC zero length arrays are allowed.  They are useful in
	 * this manner as the last element of a structure which is really
	 * a header for a variable-length object 
	 *
	 * In C standard C99, a flexible array member can be described
	 * as  before but without the 0.  Technically the sizeof operator
	 * may not be applied, but most compilers support this and the
	 * sizeof operator applied to a flexible array member returns
	 * zero, which is what is desired. */
	osptr_t msgs[];
#endif  /* defined TIROS_C90_COMPATIBLE */
} msgQ_t;




#ifndef TIROS_USER_DEFINED_FLAG_T
typedef osword_t flag_t;
#endif

/** Event Flag structure */
typedef /*@abstract@*/ struct eflag {
	plist_t waitlist;
	flag_t status;
} eflag_t;




#endif /*  _TiROS_TYPES_H_ */
