#ifndef _MSP430_COMMON_HEADER_
#define _MSP430_COMMON_HEADER_


#if defined (__GNUC__)
#include <io.h>
#include <stdint.h>
#include <signal.h>

#elif defined (__ICC430__)
#include <msp430.h>
#include <intrinsics.h>
#include <stdint.h>
#define TASSEL_ACLK TASSEL_1
#define TBSSEL_ACLK TBSSEL_1
#define MC_CONT  MC_2
#define SSEL_ACLK 0x10
#define nop() __no_operation()

#endif




#endif
