
/* On the Posix system, putchar is not needed.  It is part of
 * the C stdio library. */

