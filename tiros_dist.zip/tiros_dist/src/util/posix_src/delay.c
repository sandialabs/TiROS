#include <stdio.h>
#include <sched.h>
#include <unistd.h>
#include <time.h>

void delayms(unsigned int d)
{
	/* On a posix system, sleep does not work with signals but
	 * according to the posix specification, nanosleep should be
	 * fine because it does not use the same mechanism.  */
	struct timespec sleep_time;

	/* The delay is given in ms */
	sleep_time.tv_sec = d/1000;
	sleep_time.tv_nsec = (d - sleep_time.tv_sec * 1000) * 1000;
	nanosleep(&sleep_time, 0);
}


void delayus(unsigned int d)
{
	/* On a posix system, sleep does not work with signals but
	 * according to the posix specification, nanosleep should be
	 * fine because it does not use the same mechanism.  */
	struct timespec sleep_time;

	/* The delay is given in ms */
	sleep_time.tv_sec = d/1000000;
	sleep_time.tv_nsec = (d - sleep_time.tv_sec * 1000000) * 1000;
	nanosleep(&sleep_time, 0);	
}
