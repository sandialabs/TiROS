/** \file
 * @brief Utility functions
 *
 * $Id:$
 */
#include <util.h>



static void printnibble(unsigned char nibble) {
	if (nibble > 9){
		(void)putchar(nibble + (65-10)) ;
	} else {
		(void)putchar( nibble + 48); 
	}
}


static void puthexcharsimple(unsigned char c)
{
	printnibble( c >> 4);         /* Hi byte */
	printnibble(0x0f & c);       /* Lo byte */
}

void puthexint(uint32_t c, int intsize)
{
	switch(intsize) {
	case 4:
		puthexcharsimple((uint8_t) ((c >> 24) & 0xff) );
		/*lint -fallthrough */
	case 3:
		puthexcharsimple((uint8_t) ((c >> 16) & 0xff) );
		/*lint -fallthrough */
	case 2:
		puthexcharsimple((uint8_t) ((c >> 8) & 0xff) );
		/*lint -fallthrough */
	case 1:
		/*lint -e{835}  Right shift by zero is written for
		 * readability */
		puthexcharsimple((uint8_t) ((c >> 0) & 0xff) );
		/*lint -fallthrough */
	default:
		break;
	}
}


void puthexchar(unsigned char c) {
	(void)putchar('0');
	(void)putchar('x'); 
	puthexcharsimple(c);
}

void puthexshort(unsigned short c)
{
	(void)putchar('0');
	(void)putchar('x');
	puthexint((uint32_t) c,2 );
}


/* Write a string */
void putstring(char const *s) {
	while(*s != 0) {
		(void)putchar(*s++);
	}
	
}


void printbytesinhex(unsigned char const *bytes, int len)
{
	for(; len ; len--) {
		puthexchar(*bytes++);
		(void)putchar(' ');
	}
}

