/** \file This implements the functions defined in hal.h
 * for the specific NesDAC board
 * 
 * Author: Ratish J. Punnoose
 * $Id: hal.c 15 2006-04-18 16:36:51Z rjpunno $
 */

#include <msp430/cmn_header.h>

/*lint -esym( 750 , MSP430_DELAY_C ) */
#define MSP430_DELAY_C
#  include "proj_config.h"
#undef MSP430_DELAY_C




#include <util.h>

#ifndef CUSTOM_MSP430_DELAYUS
void delayus(unsigned int d)
{
	d = d >> 3;
	while(d--) {
		/*lint --e{123} */
		nop();
		nop();
	}
}
#endif


void delayms(unsigned int d) 
{
	while(d--) {
		/*lint -e{522} delayus has side effects */
		delayus(1000U);
	}
}

