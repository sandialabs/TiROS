#include <msp430/msp430_usart.h>

#define MSP430_PUTCHAR_CONFIG
#  include "proj_config.h"
#undef  MSP430_PUTCHAR_CONFIG

#ifndef MSP430_STDIO_USARTNUM
#  define MSP430_STDIO_USARTNUM 0
#endif


#define XUSARTPUTCHAR(x) usart ## x ## Putch
#define USARTPUTCHAR(x) XUSARTPUTCHAR(x)


/* The standard action is to write to usart0 on the msp430 */


int putchar(int c)
{
	
	//usart0Putch(c);
	USARTPUTCHAR( MSP430_STDIO_USARTNUM)((uint8_t)c);
	return c;
}

