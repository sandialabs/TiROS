/******************************************************************************
 * Warning:: Do NOT edit msp430_usart_autogen.c.
 * msp430_usart_autogen.c is automatically generated from:
 * 1. msp430_usart_def_header.c     :  Contains the header
 * 2. msp430_usart_def_body.c       :  Contains the body
 * 3. msp430_usart_def_footer.c     :  Contains the footer.
 * 
 *  Any changes can be made in the files above that are the generators.
 * This file implements the MSP430 USART in uart/spi mode.
 *  
 * Code adapted and modifed by Ratish J. Punnoose from mspgcc provided examples.
 * Copyright 2001, R O SoftWare
 *
 * $Id: msp430_usart_def_header.c 201 2010-09-21 00:17:51Z rjpunno $
 * 
 *****************************************************************************/
#include <msp430/msp430_usart.h>

// Special Function Registers for USART1
//#define U1IFG IFG2                    // USART1 RX & TX Interrupt Flag Register
//#define U1IE  IE2                     // USART1 RX & TX Interrupt Enable Register
//#define U1ME  ME2                     // USART1 RX & TX Module Enable Register


#if ((defined(MSP430_USART0_DMA_CHANNEL_TX) &&	         \
      defined(MSP430_USART0_DMA_CHANNEL_RX) )      ||    \
	(defined(MSP430_USART1_DMA_CHANNEL_TX) &&        \
	 defined(MSP430_USART1_DMA_CHANNEL_RX)))  
static unsigned char const ZERO_VALUE = 0;
#endif
#if USART0_SUPPORT


/* ChangeLog: Replaced DMA macro definitions by standard ones in
 * dma_interface.h */


#if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(USE_TIMED_DMA_FOR_UART_TRIGGER)
static inline void usart0Reset(void)
{
	U0CTL |= SWRST;
	U0CTL &= ~SWRST;	
}
#endif

void usart0Init(uint16_t baudDiv, uint8_t baudMod, uint8_t mode,
		    uint8_t clockSrc)
{
	/* According to MSP430 user's guide.
	 * 0. Set alternate function on pins 
	 * ---------------------------------------- */

	if (mode & SYNC) { // SPI Mode
		SPI0_PORTSEL  |= SPI0_PORTINIT;
		if (!(mode & BIT7))  // Not 3 pin mode
			SPI0_PORTSEL  |= SPI0_STE_PIN;
	} else { // If uart mode
		UART0_PORTSEL |= UART0_PORTINIT ;
	}



	/*    1. Set SWRST            */
	/* ---------------------------------------- */
	U0CTL  = SWRST;           


	/* 2. Initialize all USART registers while SWRST= 1 */
	/* ---------------------------------------- */
	/* For SPI mode, if 4pin option is set, then .. */
	if ( (mode & SYNC) && (mode & BIT7)  ) {
		U0TCTL = ( clockSrc | STC | CKPH) ;  // 3 pin mode
		mode &= ~BIT7;   // Remove the option bit from mode
	} else {
		U0TCTL = clockSrc;
	}


	U0RCTL = 0;

	U0BR1  = (uint8_t)(baudDiv >> 8);
	U0BR0  = (uint8_t)(baudDiv );

	U0MCTL = baudMod;


	/* 3. Enable USART modules via MEx SFRs. */
	/* ---------------------------------------- */
	if ( mode & SYNC) // SPI mode
		U0ME  |= USPIE0;
	else  //Enable USART0 
		U0ME  |= UTXE0|URXE0;      



	// 4. Clear SWRST via software
	/* ---------------------------------------- */
	U0CTL  = mode;     //init & release reset

}




void usart0Close(void)
{
	/* Set to default reset mode */
	U0CTL = SWRST;

	/* Clear Module enable registers */
	U0ME &= ~(USPIE0 | UTXE0 | URXE0) ;
}









/* Define DMA Preprocesor Macros */
#if defined (MSP430_USART0_DMA_CHANNEL_TX) || defined(MSP430_USART0_DMA_CHANNEL_RX)
#  include <msp430/dma_interface.h>



#  if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(MSP430_USART0_DMA_CHANNEL_RX) 
#    if (MSP430_USART0_DMA_CHANNEL_RX >= MSP430_USART0_DMA_CHANNEL_TX)
#      warning "RX dma channel priority should be higher than TX priority"
#    endif
#  endif



#  define xUSART0_MSPTCCTL(t, n) T ## t ## CCTL ## n
#  define USART0_MSPTCCTL(t, n) xUSART0_MSPTCCTL(t, n)

#  define xUSART0_MSPTREG(t, n) T ## t ## CCR ## n
#  define USART0_MSPTREG(t, n) xUSART0_MSPTREG(t, n)

#  define xUSART0_TIMER_DMA_TRIG(t) TRIG_T ## t ## CCR2
#  define USART0_TIMER_DMA_TRIG(t) xUSART0_TIMER_DMA_TRIG(t)

#endif


#if !(defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(MSP430_USART0_DMA_CHANNEL_RX) )
/* For timed transmissions */
#  define xUSART0_TIMER(t) T ## t ## R
#  define USART0_TIMER(t) xUSART0_TIMER(t)
#endif






int usart0TxIdle(void)
{
#ifdef MSP430_USART0_DMA_CHANNEL_TX
	if (DMA_BUSY(MSP430_USART0_DMA_CHANNEL_TX)())
		return 0;
	else
		return (UTCTL0 & TXEPT);
#else
	return (UTCTL0 & TXEPT);
#endif
}

void usart0Putch(unsigned char ch)
{

	/* Wait for TX buffer to empty. */

	WAIT_WHILE( !(usart0TxIdle()), 
		    USART0_IDLEWAIT_TIMEOUT,
		    USART0_IDLEWAIT_TMETHOD);

	TXBUF0 = ch;
}



void usart0TimedPutch(unsigned char ch, uint16_t target_time)
{

#if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(USE_TIMED_DMA_FOR_UART_TRIGGER)
	volatile unsigned char ch_tmp = ch; /* To force ch to be
					       stored on the stack */

#else
	uint16_t curr_time;
	uint16_t target_mark;
	/* Wait for time */
	target_mark = target_time + INT16_MAX;
#endif


	WAIT_WHILE( !(usart0TxIdle()), 
		    USART0_IDLEWAIT_TIMEOUT,
		    USART0_IDLEWAIT_TMETHOD);

#if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(USE_TIMED_DMA_FOR_UART_TRIGGER)
	usart0Reset();
	/* Setup compare. Disable current setup*/
	USART0_MSPTREG(MSP430_USART0_TIMER, 2) = target_time;
	USART0_MSPTCCTL(MSP430_USART0_TIMER, 2) = 0;

	/* Setup to be triggered by clock interrupt */

	DMA_SETUP(MSP430_USART0_DMA_CHANNEL_TX)(
		USART0_TIMER_DMA_TRIG(MSP430_USART0_TIMER),
		DMADT_SINGLE | 
		DMADSTADDR_CONST  |
		DMASRCADDR_CONST  | 
		DMADSTBYTE | DMASRCBYTE | 
		DMALEVEL |
		DMAEN, 
		&ch_tmp,
		(unsigned char *) &U0TXBUF,
		1);


	WAIT_WHILE(
		DMA_BUSY(MSP430_USART0_DMA_CHANNEL_TX)(),
		USART0_RW_DMATXCHANBUSY_TIMEOUT,
		USART0_RW_DMATXCHANBUSY_TMETHOD ); 

#else
	if (target_time > INT16_MAX ) {
		/* if target time is over the half way point */
		do {
			curr_time = USART0_TIMER(MSP430_USART0_TIMER);
			/* In this case, if curr_time is in the
			   interval [target_mark target_time] then
			   keep waiting */
		} while ( curr_time > target_mark && curr_time < target_time);

	} else {
		do {
			curr_time = USART0_TIMER(MSP430_USART0_TIMER);
			/* In this case, if curr_time is in the
			   interval [target_time  target_mark], then
			   stop waiting */
		} while( curr_time < target_time || curr_time > target_mark);
	}
	TXBUF0 = ch;
#endif


}




int usart0TxReady(void)
{
	return (UTCTL0 & TXEPT);
}




void usart0ReadWrite(unsigned char const *txbuf,  
			 unsigned char *rxbuf,
			 uint16_t num_bytes, uint16_t options)
{

#if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(MSP430_USART0_DMA_CHANNEL_RX) 
	uint16_t dst_addr_dir, src_addr_dir;
#else
	uint16_t ind;
#endif


	
	/* Make sure ongoing SPI transfer is completed. */
	//while(!usart0TxIdle());
	WAIT_WHILE( !(usart0TxIdle()), 
		    USART0_IDLEWAIT_TIMEOUT,
		    USART0_IDLEWAIT_TMETHOD);


	/* Clear the TXIFG flag  due to the peculiarities of the MSP
	   430 --
	   http://tech.groups.yahoo.com/group/msp430/message/26652 
	   - The Tx Interrupt occurs when the TX Shift register is empty.
	   - This interrupt is cleared when you service the interrupt (even if you do
	   not transmit another char).
	   - This means that if you enter the Tx ISR and you do not write to the TX
	   SR before returning, you will not get another Tx Interrupt, until another
	   char is written and the Tx SR empties again.

	   The Tx Interrupt is like an EDGE interrupt... it occurs on the transition
	   from full to empty. It is not like a LEVEL interrupt. It will not occur
	   just because the Tx SR is empty... only when it goes from full to empty.
	*/

	

#if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(MSP430_USART0_DMA_CHANNEL_RX) 

	/* Reset the txbuf.  */

	if (options & USART_OPTION_REVERSE_RW) {
		if (rxbuf) rxbuf += num_bytes -1;
		if (txbuf) txbuf += num_bytes -1;
		dst_addr_dir  = DMADSTADDR_DECR;
		src_addr_dir  = DMASRCADDR_DECR;
	} else {
		dst_addr_dir  = DMADSTADDR_INCR;
		src_addr_dir  = DMASRCADDR_INCR;
	}
	

	if (rxbuf) {
		/* Clear the receive interrupt register.  This may be
		   set due to prior received bytes.   	However, the
		   DMA won't fire if it is already set */ 
		U0IFG &= ~URXIFG0;


		/* dma channel 0 has highest priority. */
		DMA_SETUP(MSP430_USART0_DMA_CHANNEL_RX)(
			TRIG_URXIFG0, 
			DMADT_SINGLE | 
			dst_addr_dir |
			DMASRCADDR_CONST |
			DMADSTBYTE | DMASRCBYTE | DMAEN,  
			(unsigned char *) & U0RXBUF , 
			rxbuf,
			num_bytes); 
	}


	/* NOTE: Trigger should be disabled before the dma transfer is
	 * started, otherwise  the DMA transfer will not start. Check Sec
	 * 8.2.3 Initiating DMA transfers:
	 * We can do this in two ways:
	 * 1. Forcing U0IFG off, setting up dma, turning it on.
	 * 2. Setting DMALEVEL for level trigger.
	 */	
	if (txbuf) {
		DMA_SETUP(MSP430_USART0_DMA_CHANNEL_TX)(
			TRIG_UTXIFG0, 
			DMADT_SINGLE | 
			DMADSTADDR_CONST  |
			src_addr_dir  | 
			DMADSTBYTE | DMASRCBYTE | 
			DMALEVEL |
			DMAEN, 
			txbuf,
			(unsigned char *) &U0TXBUF,
			num_bytes);
		
	} else {
		DMA_SETUP(MSP430_USART0_DMA_CHANNEL_TX)(
			TRIG_UTXIFG0, 
			DMADT_SINGLE | 
			DMADSTADDR_CONST |
			DMASRCADDR_CONST | 
			DMADSTBYTE | DMASRCBYTE | 
			DMALEVEL |
			DMAEN, 
			&ZERO_VALUE, (unsigned char *) &U0TXBUF,
			num_bytes);
	}

	/* If we are doing an asynchronous write, then don't wait
	 * until the write is done */
	if (options & USART_OPTION_ASYNC) {
		return;
	}

	if (rxbuf) {
		//while(dmaChan0Busy() );
		WAIT_WHILE(
			DMA_BUSY(MSP430_USART0_DMA_CHANNEL_RX)(),
			USART0_RW_DMARXCHANBUSY_TIMEOUT,
			USART0_RW_DMARXCHANBUSY_TMETHOD ); 
	} else {
		//while(dmaChan1Busy());
		WAIT_WHILE(
			DMA_BUSY(MSP430_USART0_DMA_CHANNEL_TX)(),
			USART0_RW_DMATXCHANBUSY_TIMEOUT,
			USART0_RW_DMATXCHANBUSY_TMETHOD ); 
	}
	
#else

	/* This was previously written this loop in an unrolled
	 * manner for each combination.  But changed it to
	 * this.  This loop is 
	 * smaller and reads more concisely at a penalty of
	 * checking the flags during every loop iteration. --- RJP */
	
	if (options & USART_OPTION_REVERSE_RW) {
		if (rxbuf) rxbuf += num_bytes -1;
		if (txbuf) txbuf += num_bytes -1;
		for (ind=num_bytes; ind; ind--) {
			if (txbuf) usart0Putch(*txbuf--);
			else { /* Need to write something out for SPI
				  mode */
				usart0Putch(0);
			}
			if (rxbuf) 
				*rxbuf-- = usart0Getch();
		}
	} else {
		for (ind=num_bytes; ind; ind--) {
			if (txbuf) usart0Putch(*txbuf++);
			else { /* Need to write something out for SPI
				  mode */
				usart0Putch(0);
			}
		
			if (rxbuf) 
				*rxbuf++ = usart0Getch();
		}
	}
#endif


}
			 




void usart0WriteWithOptions(unsigned char const * txbuf, uint16_t num_bytes, uint16_t options)
{
	(void)options; /* May or may not be used */
#if defined(MSP430_USART0_DMA_CHANNEL_TX) && defined(MSP430_USART0_DMA_CHANNEL_RX) 

#else
	uint16_t ind;
#endif

	/* Make sure ongoing SPI transfer is completed. */
	//while(!usart0TxIdle());
	WAIT_WHILE( !(usart0TxIdle()), 
		    USART0_IDLEWAIT_TIMEOUT,
		    USART0_IDLEWAIT_TMETHOD);


	

#if defined(MSP430_USART0_DMA_CHANNEL_TX)
	/* NOTE: Trigger should be disabled before the dma transfer is
	 * started, otherwise  the DMA transfer will not start. Check Sec
	 * 8.2.3 Initiating DMA transfers:
	 * We can do this in two ways:
	 * 1. Forcing U0IFG off, setting up dma, turning it on.
	 * 2. Setting DMALEVEL for level trigger.
	 */	
	if (txbuf) {
		DMA_SETUP(MSP430_USART0_DMA_CHANNEL_TX)(
			TRIG_UTXIFG0, 
			DMADT_SINGLE | 
			DMADSTADDR_CONST  |
			DMASRCADDR_INCR  | 
			DMADSTBYTE | DMASRCBYTE | 
			DMALEVEL |
			DMAEN, 
			txbuf,
			(unsigned char *) &U0TXBUF,
			num_bytes);
		
	} 

	/* If we are doing an asynchronous write, then don't wait
	 * until the write is done */
	if (options & USART_OPTION_ASYNC) {
		return;
	}

	WAIT_WHILE(
		DMA_BUSY(MSP430_USART0_DMA_CHANNEL_TX)(),
		USART0_RW_DMATXCHANBUSY_TIMEOUT,
		USART0_RW_DMATXCHANBUSY_TMETHOD ); 

#else
	
	for (ind=num_bytes; ind; ind--) {
		usart0Putch(*txbuf++);
	}
#endif

}

void usart0Write(unsigned char const *txbuf, uint16_t num_bytes)
{
	usart0WriteWithOptions(txbuf, num_bytes, 0);
}


void usart0Read(unsigned char *rxbuf, uint16_t num_bytes)
{

#if defined(MSP430_USART0_DMA_CHANNEL_RX) 
	uint16_t dst_addr_dir;
#else
	uint16_t ind;
#endif


	
	/* Make sure ongoing SPI transfer is completed. */
	//while(!usart0TxIdle());
	WAIT_WHILE( !(usart0TxIdle()), 
		    USART0_IDLEWAIT_TIMEOUT,
		    USART0_IDLEWAIT_TMETHOD);

	

#if defined(MSP430_USART0_DMA_CHANNEL_RX) 

	/* Reset the txbuf.  */
	dst_addr_dir  = DMADSTADDR_INCR;

	/* Clear the receive interrupt register.  This may be
	   set due to prior received bytes.   	However, the
	   DMA won't fire if it is already set */ 
	U0IFG &= ~URXIFG0;


	/* dma channel 0 has highest priority. */
	DMA_SETUP(MSP430_USART0_DMA_CHANNEL_RX)(
		TRIG_URXIFG0, 
		DMADT_SINGLE | 
		dst_addr_dir |
		DMASRCADDR_CONST |
		DMADSTBYTE | DMASRCBYTE | DMAEN,  
		(unsigned char *) & U0RXBUF , 
		rxbuf,
		num_bytes); 



	//while(dmaChan0Busy() );
	WAIT_WHILE(
		DMA_BUSY(MSP430_USART0_DMA_CHANNEL_RX)(),
		USART0_RW_DMARXCHANBUSY_TIMEOUT,
		USART0_RW_DMARXCHANBUSY_TMETHOD ); 
	
#else

	/* This was previously written this loop in an unrolled
	 * manner for each combination.  But changed it to
	 * this.  This loop is 
	 * smaller and reads more concisely at a penalty of
	 * checking the flags during every loop iteration. --- RJP */
	for (ind=num_bytes; ind; ind--) {
		*rxbuf++ = usart0Getch();
		
	}
#endif


}
			 





void usart0RxFlush(void)
{
	// Clear any receive interrupts.
	U0IFG &= ~URXIFG0;
}


int usart0RxReady(void)
{
	int rc;
	if ((U0IFG & URXIFG0)  && !(URCTL0 & (FE|PE|BRK) ))
		rc = 1;
	else 
		rc = 0;

	return rc;
}


int usart0RxStatus(void)
{
	int rc;
	if (!(URCTL0 & (FE|PE|BRK)))
		rc = -1;
	else {
		if (U0IFG & URXIFG0)
			rc = 1;
		else 
			rc = 0;
	}

	return rc;
}


void usart0TxFlush(void)
{
}

uint8_t usart0Getch(void)
{
	uint8_t ch;
	for(;;) {
		//while ( !(U0IFG & URXIFG0));
		WAIT_WHILE ( !(U0IFG & URXIFG0),
			     USART0_GETCH_TIMEOUT,
			     USART0_GETCH_TMETHOD) ;


		if (URCTL0 & (FE|PE|BRK) ) 
			ch = RXBUF0;
		else {
			ch = RXBUF0;			
			break;
		}
	}	
	return ch;
}






#endif  //usart0 definitions

#if USART1_SUPPORT


/* ChangeLog: Replaced DMA macro definitions by standard ones in
 * dma_interface.h */


#if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(USE_TIMED_DMA_FOR_UART_TRIGGER)
static inline void usart1Reset(void)
{
	U1CTL |= SWRST;
	U1CTL &= ~SWRST;	
}
#endif

void usart1Init(uint16_t baudDiv, uint8_t baudMod, uint8_t mode,
		    uint8_t clockSrc)
{
	/* According to MSP430 user's guide.
	 * 0. Set alternate function on pins 
	 * ---------------------------------------- */

	if (mode & SYNC) { // SPI Mode
		SPI1_PORTSEL  |= SPI1_PORTINIT;
		if (!(mode & BIT7))  // Not 3 pin mode
			SPI1_PORTSEL  |= SPI1_STE_PIN;
	} else { // If uart mode
		UART1_PORTSEL |= UART1_PORTINIT ;
	}



	/*    1. Set SWRST            */
	/* ---------------------------------------- */
	U1CTL  = SWRST;           


	/* 2. Initialize all USART registers while SWRST= 1 */
	/* ---------------------------------------- */
	/* For SPI mode, if 4pin option is set, then .. */
	if ( (mode & SYNC) && (mode & BIT7)  ) {
		U1TCTL = ( clockSrc | STC | CKPH) ;  // 3 pin mode
		mode &= ~BIT7;   // Remove the option bit from mode
	} else {
		U1TCTL = clockSrc;
	}


	U1RCTL = 0;

	U1BR1  = (uint8_t)(baudDiv >> 8);
	U1BR0  = (uint8_t)(baudDiv );

	U1MCTL = baudMod;


	/* 3. Enable USART modules via MEx SFRs. */
	/* ---------------------------------------- */
	if ( mode & SYNC) // SPI mode
		U1ME  |= USPIE1;
	else  //Enable USART1 
		U1ME  |= UTXE1|URXE1;      



	// 4. Clear SWRST via software
	/* ---------------------------------------- */
	U1CTL  = mode;     //init & release reset

}




void usart1Close(void)
{
	/* Set to default reset mode */
	U1CTL = SWRST;

	/* Clear Module enable registers */
	U1ME &= ~(USPIE1 | UTXE1 | URXE1) ;
}









/* Define DMA Preprocesor Macros */
#if defined (MSP430_USART1_DMA_CHANNEL_TX) || defined(MSP430_USART1_DMA_CHANNEL_RX)
#  include <msp430/dma_interface.h>



#  if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(MSP430_USART1_DMA_CHANNEL_RX) 
#    if (MSP430_USART1_DMA_CHANNEL_RX >= MSP430_USART1_DMA_CHANNEL_TX)
#      warning "RX dma channel priority should be higher than TX priority"
#    endif
#  endif



#  define xUSART1_MSPTCCTL(t, n) T ## t ## CCTL ## n
#  define USART1_MSPTCCTL(t, n) xUSART1_MSPTCCTL(t, n)

#  define xUSART1_MSPTREG(t, n) T ## t ## CCR ## n
#  define USART1_MSPTREG(t, n) xUSART1_MSPTREG(t, n)

#  define xUSART1_TIMER_DMA_TRIG(t) TRIG_T ## t ## CCR2
#  define USART1_TIMER_DMA_TRIG(t) xUSART1_TIMER_DMA_TRIG(t)

#endif


#if !(defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(MSP430_USART1_DMA_CHANNEL_RX) )
/* For timed transmissions */
#  define xUSART1_TIMER(t) T ## t ## R
#  define USART1_TIMER(t) xUSART1_TIMER(t)
#endif






int usart1TxIdle(void)
{
#ifdef MSP430_USART1_DMA_CHANNEL_TX
	if (DMA_BUSY(MSP430_USART1_DMA_CHANNEL_TX)())
		return 0;
	else
		return (UTCTL1 & TXEPT);
#else
	return (UTCTL1 & TXEPT);
#endif
}

void usart1Putch(unsigned char ch)
{

	/* Wait for TX buffer to empty. */

	WAIT_WHILE( !(usart1TxIdle()), 
		    USART1_IDLEWAIT_TIMEOUT,
		    USART1_IDLEWAIT_TMETHOD);

	TXBUF1 = ch;
}



void usart1TimedPutch(unsigned char ch, uint16_t target_time)
{

#if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(USE_TIMED_DMA_FOR_UART_TRIGGER)
	volatile unsigned char ch_tmp = ch; /* To force ch to be
					       stored on the stack */

#else
	uint16_t curr_time;
	uint16_t target_mark;
	/* Wait for time */
	target_mark = target_time + INT16_MAX;
#endif


	WAIT_WHILE( !(usart1TxIdle()), 
		    USART1_IDLEWAIT_TIMEOUT,
		    USART1_IDLEWAIT_TMETHOD);

#if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(USE_TIMED_DMA_FOR_UART_TRIGGER)
	usart1Reset();
	/* Setup compare. Disable current setup*/
	USART1_MSPTREG(MSP430_USART1_TIMER, 2) = target_time;
	USART1_MSPTCCTL(MSP430_USART1_TIMER, 2) = 0;

	/* Setup to be triggered by clock interrupt */

	DMA_SETUP(MSP430_USART1_DMA_CHANNEL_TX)(
		USART1_TIMER_DMA_TRIG(MSP430_USART1_TIMER),
		DMADT_SINGLE | 
		DMADSTADDR_CONST  |
		DMASRCADDR_CONST  | 
		DMADSTBYTE | DMASRCBYTE | 
		DMALEVEL |
		DMAEN, 
		&ch_tmp,
		(unsigned char *) &U1TXBUF,
		1);


	WAIT_WHILE(
		DMA_BUSY(MSP430_USART1_DMA_CHANNEL_TX)(),
		USART1_RW_DMATXCHANBUSY_TIMEOUT,
		USART1_RW_DMATXCHANBUSY_TMETHOD ); 

#else
	if (target_time > INT16_MAX ) {
		/* if target time is over the half way point */
		do {
			curr_time = USART1_TIMER(MSP430_USART1_TIMER);
			/* In this case, if curr_time is in the
			   interval [target_mark target_time] then
			   keep waiting */
		} while ( curr_time > target_mark && curr_time < target_time);

	} else {
		do {
			curr_time = USART1_TIMER(MSP430_USART1_TIMER);
			/* In this case, if curr_time is in the
			   interval [target_time  target_mark], then
			   stop waiting */
		} while( curr_time < target_time || curr_time > target_mark);
	}
	TXBUF1 = ch;
#endif


}




int usart1TxReady(void)
{
	return (UTCTL1 & TXEPT);
}




void usart1ReadWrite(unsigned char const *txbuf,  
			 unsigned char *rxbuf,
			 uint16_t num_bytes, uint16_t options)
{

#if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(MSP430_USART1_DMA_CHANNEL_RX) 
	uint16_t dst_addr_dir, src_addr_dir;
#else
	uint16_t ind;
#endif


	
	/* Make sure ongoing SPI transfer is completed. */
	//while(!usart1TxIdle());
	WAIT_WHILE( !(usart1TxIdle()), 
		    USART1_IDLEWAIT_TIMEOUT,
		    USART1_IDLEWAIT_TMETHOD);


	/* Clear the TXIFG flag  due to the peculiarities of the MSP
	   430 --
	   http://tech.groups.yahoo.com/group/msp430/message/26652 
	   - The Tx Interrupt occurs when the TX Shift register is empty.
	   - This interrupt is cleared when you service the interrupt (even if you do
	   not transmit another char).
	   - This means that if you enter the Tx ISR and you do not write to the TX
	   SR before returning, you will not get another Tx Interrupt, until another
	   char is written and the Tx SR empties again.

	   The Tx Interrupt is like an EDGE interrupt... it occurs on the transition
	   from full to empty. It is not like a LEVEL interrupt. It will not occur
	   just because the Tx SR is empty... only when it goes from full to empty.
	*/

	

#if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(MSP430_USART1_DMA_CHANNEL_RX) 

	/* Reset the txbuf.  */

	if (options & USART_OPTION_REVERSE_RW) {
		if (rxbuf) rxbuf += num_bytes -1;
		if (txbuf) txbuf += num_bytes -1;
		dst_addr_dir  = DMADSTADDR_DECR;
		src_addr_dir  = DMASRCADDR_DECR;
	} else {
		dst_addr_dir  = DMADSTADDR_INCR;
		src_addr_dir  = DMASRCADDR_INCR;
	}
	

	if (rxbuf) {
		/* Clear the receive interrupt register.  This may be
		   set due to prior received bytes.   	However, the
		   DMA won't fire if it is already set */ 
		U1IFG &= ~URXIFG1;


		/* dma channel 0 has highest priority. */
		DMA_SETUP(MSP430_USART1_DMA_CHANNEL_RX)(
			TRIG_URXIFG1, 
			DMADT_SINGLE | 
			dst_addr_dir |
			DMASRCADDR_CONST |
			DMADSTBYTE | DMASRCBYTE | DMAEN,  
			(unsigned char *) & U1RXBUF , 
			rxbuf,
			num_bytes); 
	}


	/* NOTE: Trigger should be disabled before the dma transfer is
	 * started, otherwise  the DMA transfer will not start. Check Sec
	 * 8.2.3 Initiating DMA transfers:
	 * We can do this in two ways:
	 * 1. Forcing U1IFG off, setting up dma, turning it on.
	 * 2. Setting DMALEVEL for level trigger.
	 */	
	if (txbuf) {
		DMA_SETUP(MSP430_USART1_DMA_CHANNEL_TX)(
			TRIG_UTXIFG1, 
			DMADT_SINGLE | 
			DMADSTADDR_CONST  |
			src_addr_dir  | 
			DMADSTBYTE | DMASRCBYTE | 
			DMALEVEL |
			DMAEN, 
			txbuf,
			(unsigned char *) &U1TXBUF,
			num_bytes);
		
	} else {
		DMA_SETUP(MSP430_USART1_DMA_CHANNEL_TX)(
			TRIG_UTXIFG1, 
			DMADT_SINGLE | 
			DMADSTADDR_CONST |
			DMASRCADDR_CONST | 
			DMADSTBYTE | DMASRCBYTE | 
			DMALEVEL |
			DMAEN, 
			&ZERO_VALUE, (unsigned char *) &U1TXBUF,
			num_bytes);
	}

	/* If we are doing an asynchronous write, then don't wait
	 * until the write is done */
	if (options & USART_OPTION_ASYNC) {
		return;
	}

	if (rxbuf) {
		//while(dmaChan0Busy() );
		WAIT_WHILE(
			DMA_BUSY(MSP430_USART1_DMA_CHANNEL_RX)(),
			USART1_RW_DMARXCHANBUSY_TIMEOUT,
			USART1_RW_DMARXCHANBUSY_TMETHOD ); 
	} else {
		//while(dmaChan1Busy());
		WAIT_WHILE(
			DMA_BUSY(MSP430_USART1_DMA_CHANNEL_TX)(),
			USART1_RW_DMATXCHANBUSY_TIMEOUT,
			USART1_RW_DMATXCHANBUSY_TMETHOD ); 
	}
	
#else

	/* This was previously written this loop in an unrolled
	 * manner for each combination.  But changed it to
	 * this.  This loop is 
	 * smaller and reads more concisely at a penalty of
	 * checking the flags during every loop iteration. --- RJP */
	
	if (options & USART_OPTION_REVERSE_RW) {
		if (rxbuf) rxbuf += num_bytes -1;
		if (txbuf) txbuf += num_bytes -1;
		for (ind=num_bytes; ind; ind--) {
			if (txbuf) usart1Putch(*txbuf--);
			else { /* Need to write something out for SPI
				  mode */
				usart1Putch(0);
			}
			if (rxbuf) 
				*rxbuf-- = usart1Getch();
		}
	} else {
		for (ind=num_bytes; ind; ind--) {
			if (txbuf) usart1Putch(*txbuf++);
			else { /* Need to write something out for SPI
				  mode */
				usart1Putch(0);
			}
		
			if (rxbuf) 
				*rxbuf++ = usart1Getch();
		}
	}
#endif


}
			 




void usart1WriteWithOptions(unsigned char const * txbuf, uint16_t num_bytes, uint16_t options)
{
	(void)options; /* May or may not be used */
#if defined(MSP430_USART1_DMA_CHANNEL_TX) && defined(MSP430_USART1_DMA_CHANNEL_RX) 

#else
	uint16_t ind;
#endif

	/* Make sure ongoing SPI transfer is completed. */
	//while(!usart1TxIdle());
	WAIT_WHILE( !(usart1TxIdle()), 
		    USART1_IDLEWAIT_TIMEOUT,
		    USART1_IDLEWAIT_TMETHOD);


	

#if defined(MSP430_USART1_DMA_CHANNEL_TX)
	/* NOTE: Trigger should be disabled before the dma transfer is
	 * started, otherwise  the DMA transfer will not start. Check Sec
	 * 8.2.3 Initiating DMA transfers:
	 * We can do this in two ways:
	 * 1. Forcing U1IFG off, setting up dma, turning it on.
	 * 2. Setting DMALEVEL for level trigger.
	 */	
	if (txbuf) {
		DMA_SETUP(MSP430_USART1_DMA_CHANNEL_TX)(
			TRIG_UTXIFG1, 
			DMADT_SINGLE | 
			DMADSTADDR_CONST  |
			DMASRCADDR_INCR  | 
			DMADSTBYTE | DMASRCBYTE | 
			DMALEVEL |
			DMAEN, 
			txbuf,
			(unsigned char *) &U1TXBUF,
			num_bytes);
		
	} 

	/* If we are doing an asynchronous write, then don't wait
	 * until the write is done */
	if (options & USART_OPTION_ASYNC) {
		return;
	}

	WAIT_WHILE(
		DMA_BUSY(MSP430_USART1_DMA_CHANNEL_TX)(),
		USART1_RW_DMATXCHANBUSY_TIMEOUT,
		USART1_RW_DMATXCHANBUSY_TMETHOD ); 

#else
	
	for (ind=num_bytes; ind; ind--) {
		usart1Putch(*txbuf++);
	}
#endif

}

void usart1Write(unsigned char const *txbuf, uint16_t num_bytes)
{
	usart1WriteWithOptions(txbuf, num_bytes, 0);
}


void usart1Read(unsigned char *rxbuf, uint16_t num_bytes)
{

#if defined(MSP430_USART1_DMA_CHANNEL_RX) 
	uint16_t dst_addr_dir;
#else
	uint16_t ind;
#endif


	
	/* Make sure ongoing SPI transfer is completed. */
	//while(!usart1TxIdle());
	WAIT_WHILE( !(usart1TxIdle()), 
		    USART1_IDLEWAIT_TIMEOUT,
		    USART1_IDLEWAIT_TMETHOD);

	

#if defined(MSP430_USART1_DMA_CHANNEL_RX) 

	/* Reset the txbuf.  */
	dst_addr_dir  = DMADSTADDR_INCR;

	/* Clear the receive interrupt register.  This may be
	   set due to prior received bytes.   	However, the
	   DMA won't fire if it is already set */ 
	U1IFG &= ~URXIFG1;


	/* dma channel 0 has highest priority. */
	DMA_SETUP(MSP430_USART1_DMA_CHANNEL_RX)(
		TRIG_URXIFG1, 
		DMADT_SINGLE | 
		dst_addr_dir |
		DMASRCADDR_CONST |
		DMADSTBYTE | DMASRCBYTE | DMAEN,  
		(unsigned char *) & U1RXBUF , 
		rxbuf,
		num_bytes); 



	//while(dmaChan0Busy() );
	WAIT_WHILE(
		DMA_BUSY(MSP430_USART1_DMA_CHANNEL_RX)(),
		USART1_RW_DMARXCHANBUSY_TIMEOUT,
		USART1_RW_DMARXCHANBUSY_TMETHOD ); 
	
#else

	/* This was previously written this loop in an unrolled
	 * manner for each combination.  But changed it to
	 * this.  This loop is 
	 * smaller and reads more concisely at a penalty of
	 * checking the flags during every loop iteration. --- RJP */
	for (ind=num_bytes; ind; ind--) {
		*rxbuf++ = usart1Getch();
		
	}
#endif


}
			 





void usart1RxFlush(void)
{
	// Clear any receive interrupts.
	U1IFG &= ~URXIFG1;
}


int usart1RxReady(void)
{
	int rc;
	if ((U1IFG & URXIFG1)  && !(URCTL1 & (FE|PE|BRK) ))
		rc = 1;
	else 
		rc = 0;

	return rc;
}


int usart1RxStatus(void)
{
	int rc;
	if (!(URCTL1 & (FE|PE|BRK)))
		rc = -1;
	else {
		if (U1IFG & URXIFG1)
			rc = 1;
		else 
			rc = 0;
	}

	return rc;
}


void usart1TxFlush(void)
{
}

uint8_t usart1Getch(void)
{
	uint8_t ch;
	for(;;) {
		//while ( !(U1IFG & URXIFG1));
		WAIT_WHILE ( !(U1IFG & URXIFG1),
			     USART1_GETCH_TIMEOUT,
			     USART1_GETCH_TMETHOD) ;


		if (URCTL1 & (FE|PE|BRK) ) 
			ch = RXBUF1;
		else {
			ch = RXBUF1;			
			break;
		}
	}	
	return ch;
}






#endif  //usart1 definitions


/*
 * msp430_usart_autogen.c is automatically generated from:
 * 1. msp430_usart_def_header.c     :  Contains the header
 * 2. msp430_usart_def_body.c       :  Contains the body
 * 3. msp430_usart_def_footer.c     :  Contains the footer.
*/
