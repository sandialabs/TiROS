This is a simple application that exercises the TiROS hardware port.
It does some simple task level context switching and also some timer
driven interrupt level context switch.
