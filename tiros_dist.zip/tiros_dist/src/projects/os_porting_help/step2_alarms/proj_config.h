
/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */
#  define TIROS_DEBUG_LEVEL 0
#  define TIROS_MAX_PROCS 10


#  ifdef __POSIX_TIROS_PORT_H
#  endif

#  ifdef __MSP430GCC_TIROS_PORT_H
#  endif

#endif 
/* ---------------------------------------------------------------- */



