This is a very simple application that tests out context
initialization and simple context switching from a task level.

