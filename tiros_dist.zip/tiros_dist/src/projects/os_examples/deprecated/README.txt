The examples in these directories were
for the priority inheritance protocol that is now deprecated in the
current release.  See release notes.
The Priority Ceiling Protocol is the default and the only option
available. It has simpler but has the benefits of the Priority
Inheritance Protocol and then some.




