
void platform_init(void)
{

}
