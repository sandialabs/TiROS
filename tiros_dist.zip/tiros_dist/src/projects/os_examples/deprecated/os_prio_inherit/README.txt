This test project demonstrates priority inheritance and fallback
as described in the TiROS users manual.

Following is the example output from the program.
The first column provides the taskID, the second and third column
provide the base and elevated priority of the task.
In this example there are four high priority tasks (numbered 0x00 -
0x03) and one low priority task (numbered 0x04).  The task ID reflects
their relative priority. 

The program is written so that the low priority task can lock a common
mutex before any of the higher priority tasks.  This is accomplished
using counting semaphores.   There is a counting semaphore (CS)
corresponding to each high priority task on which that task waits P().
The low priority task releases them (by performing a V() on the
corresponding CS).  The tasks are released in order of lower priority (0x03) to
high priority.

==================================================
R       Running - HP
P       Achieved a P() on CS - HP
L       Locked mutex - HP
U       Unlocked mutex - HP
r       Running - LP
l       Locked mutex - LP
u       Unlocked mutex - LP
v       Did a V() on CS - LP
0-3      Before and after V on CS - LP

Task    Prio    Elev    Msg
--------------------------------------------------
T0x00   0x00    0x00    R
T0x01   0x01    0x01    R
T0x02   0x02    0x02    R                                                     
T0x03   0x03    0x03    R      # All HP tasks are blocked on their CS          
T0x04   0x04    0x04    r      # LP task runs.                                
T0x04   0x04    0x04    l      # LP locks common mutex.                       
T0x04   0x04    0x04    3      # LP releases CS for task 0x03                 
T0x03   0x03    0x03    P      # HP 0x03 runs and blocks on common mutex      
T0x04   0x04    0x03    v      # LP runs again with elevated priority of 0x03.
T0x04   0x04    0x03    2      # LP releases CS for task 0x02
T0x02   0x02    0x02    P      # HP 0x02 runs and blocks on common mutex
T0x04   0x04    0x02    v      # LP runs with elevated priority of 0x02
T0x04   0x04    0x02    1      # LP releases CS for task 0x01
T0x01   0x01    0x01    P      # HP 0x01 runs and blocks on common mutex
T0x04   0x04    0x01    v      # LP runs with elevated priority of 0x01
T0x04   0x04    0x01    0      # LP releases CS for task 0x00
T0x00   0x00    0x00    P      # HP 0x00 runs and blocks on common mutex
T0x04   0x04    0x00    v      # LP runs with elevated priority of 0x00. 
                               # Now LP proceeds to unlock the mutex

T0x00   0x00    0x00    L      # HP 0x00 acquires the mutex.
T0x00   0x00    0x00    U      # HP 0x00 unlocks the mutex.
T0x00   0x00    0x00    R      # HP 0x00 runs and blocks  on its CS.

T0x01   0x01    0x01    L      # HP 0x01 acquires the mutex.        
T0x01   0x01    0x01    U      # HP 0x01 unlocks the mutex.         
T0x01   0x01    0x01    R      # HP 0x01 runs and blocks  on its CS.

T0x02   0x02    0x02    L      # HP 0x02 acquires the mutex.        
T0x02   0x02    0x02    U      # HP 0x02 unlocks the mutex.         
T0x02   0x02    0x02    R      # HP 0x02 runs and blocks  on its CS.

T0x03   0x03    0x03    L      # HP 0x03 acquires the mutex.        
T0x03   0x03    0x03    U      # HP 0x03 unlocks the mutex.         
T0x03   0x03    0x03    R      # HP 0x03 runs and blocks  on its CS.

T0x04   0x04    0x04    u      # LP runs finally. **********
T0x04   0x04    0x04    r      # NOTE that its effective priority has
                               # now  fallen back to its base priority.
T0x04   0x04    0x04    l
T0x04   0x04    0x04    3


