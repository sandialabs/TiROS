TiROS implements full cascaded priority inheritance and also the
Immediate Priority Ceiling Protocol.

This example illustrates how the TiROS implementation can avoid 
chained blocking.  This is superior to a "Simple Priority
Inheritance" implementation.
Refer to the "Simple Priority Inheritance" section of the manual,
Scenario 4.  

The sequence of events is as follows:
  - At time t1, low priority task, J3 acquires mutex, M1.
  - At time t2,  J2 wakes and runs.
  - At time t3, J2 locks mutex M2.
  - At time t4, J2 attempts to lock mutex, M1. J2 is blocked. J3
    starts running with the priority of J2.   
  - At time t5, J0 wakes and runs.
  - At time t6, J0 attempts to lock mutex M2.  M2 is already 
    locked by J2.  J0 is blocked and the priority of J2 is raised to
    that of J0.
    So far the behaviour is the same as the Simple Priority
    Inheritance Protocol. 

    * With the Simple Protocol, J3 would continue to run at the priority
    of J2.
    ** With the cascaded priority inheritance, J3 would now run at the
    priority of J0.  Note, that J3 and J0 do not have any common
    interest, i.e., they are not vying for the same mutex. 


  - At time t7, J1 wakes up and runs.
    * With the Simple Protocol, it would preempting J3 (which is running
    at the priority of J2) and J0 will be effectively blocked by J1
    which is running a long computation.  
    ** With the Cascaded Protocol, J1 cannot run at t7, because J3 has
    an effective priority of J0.  This prevents the priority inversion.




This example project demonstrates this.   Counting Semaphores are used
to achieve the timing relationship.


The task priorities are as follows:
M2 : priority ceiling 0
J0 : 1
J1 : 2
M1 : priority ceiling 3
J2 : 4
J3 : 5


If priority inheritance protocol is enabled, (set
TIROS_PRIO_INHERIT_PROTOCOL in your proj_config.h)  we get the following result.



==================================================

R       Running - HP
P       Achieved a P() on CS - HP
L       Locked mutex - HP
U       Unlocked mutex - HP
r       Running - LP
l       Locked mutex - LP
u       Unlocked mutex - LP
v       Did a V() on CS - LP
0-4      Before and after V on CS - LP
Task    Prio    Elev    Msg
--------------------------------------------------
J0 waiting for signal
J1 waiting for signal
J2 waiting for signal
T0x03   0x05    0x05    r         # J3 runs
T0x03   0x05    0x05    l         # J3 locks M1
J3 signaling J2 to run
J2 got signal
T0x02   0x04    0x04    P         # J2 runs
J2 locking m2                     # J2 locks M2
T0x02   0x04    0x04    L         
J2 locking m1                     # J2 tries to lock M1 and is blocked
T0x03   0x05    0x04    v         # J3 resumes.
J3 signaling J0 to run            
J0 got signal                     # J0 starts to run
T0x00   0x01    0x01    P         # J0 attempts to lock M2 (locked by J2)
J0 locking M2
T0x03   0x05    0x01    v         # J3 resumes again.  Note that the
                                  # effective priority of J3 is that
				  # of J0

J3 signaling J1 to run            # J1 is ready to run. 
                                  # However since the effective
				  # priority of J3 is higher, J3 takes
				  # priority. 


T0x03   0x05    0x01    v         
J3 unlocking M1                   # J3 releases the mutex
T0x02   0x04    0x01    L         # J2 can now run,

J2 unlocking m1                   # J2 releases M1
T0x02   0x04    0x01    U         
J2 unlocking m2                   # J2 releases M2, enabling J0 to run
T0x00   0x01    0x01    L         # J0 runs.
J0 unlocking M2                   # J0 releases M2.
T0x00   0x01    0x01    U
J0 waiting for signal

J1 got signal: running            # J1 can run, now that J0 is done.






===============================================================
If  the Priority Ceiling Protocol is used (uncomment the definition
for TIROS_PRIO_INHERIT_PROTOCOL in the proj_config.h file), we get this different
output that also avoids priority inversion.




R       Running - HP
P       Achieved a P() on CS - HP
L       Locked mutex - HP
U       Unlocked mutex - HP
r       Running - LP
l       Locked mutex - LP
u       Unlocked mutex - LP
v       Did a V() on CS - LP
0-4      Before and after V on CS - LP
Task    Prio    Elev    Msg
--------------------------------------------------
J0 waiting for signal
J1 waiting for signal
J2 waiting for signal
T0x03   0x05    0x05    r
T0x03   0x05    0x03    l       # J3 locks M1. Prio ceiling of M1 is
                                #

J3 signaling J2 to run
T0x03   0x05    0x03    v       # J3 is raised to prio ceiling of M1
                                # which is higher than priority of J2

J3 signaling J0 to run          
J0 got signal                   # J0 begins to run.
T0x00   0x01    0x01    P       # J0 locks M2
J0 locking M2
T0x00   0x01    0x00    L
J0 unlocking M2
T0x00   0x01    0x01    U       # J0 unlocks M2
J0 waiting for signal

T0x03   0x05    0x03    v       # J3 is still running at prio ceiling
                                # of M1

J3 signaling J1 to run          # J1 can run and it does 
J1 got signal: running
J1 waiting for signal
T0x03   0x05    0x03    v       # J3 runs again and unlocks M1
J3 unlocking M1

J2 got signal                   # J2 runs now
T0x02   0x04    0x04    P       
J2 locking m2                   # J2 locks m2 and its priority is raised.
T0x02   0x04    0x00    L       
J2 locking m1                   # J2 attempts to lock M1.

                                # ****** Note *****
				# J2s attempt to lock M1 fails.

J2 lock errorT0x02      0x04    0x00    L    
                                # J2 cannot lock M1 because J2's
				# effective prio is higher than the priority
                                # ceiling of M1.
				# This is by design.  This rule of the
                                # priority ceiling protocol prevents
                                # deadlocks.
				


J2 unlocking m1
HP unlock errorT0x02    0x04    0x00    U
J2 unlocking m2
T0x02   0x04    0x04    U
J2 waiting for signal
T0x03   0x05    0x05    r
T0x03   0x05    0x03    l
J3 signaling J2 to run
T0x03   0x05    0x03    v
J3 signaling J0 to run
J0 got signal
T0x00   0x01    0x01    P
J0 locking M2
T0x00   0x01    0x00    L
J0 unlocking M2
T0x00   0x01    0x01    U
J0 waiting for signal
T0x03   0x05    0x03    v
J3 signaling J1 to run
J1 got signal: running
J1 waiting for signal
T0x03   0x05    0x03    v


