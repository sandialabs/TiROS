#include <util.h>
#include <msp430/msp430_usart.h>


// Setup clock speeds.
#define LFXT1CLK 32.768e3
#define ACLK     LFXT1CLK
#define SMCLK    800000


// Configure USART0
// Maximum USART baud rate is clock/3.
#define BAUD_RATE 	       9600
//#define USART0_BRCLK      SMCLK
//#define USART0_BRSEL      (SSEL_SMCLK)
#define USART0_BRCLK      ACLK
#define USART0_BRSEL      (SSEL_ACLK)



void platform_init(void)
{
	
	//WDTCTL = WDTCTL_INIT;               //Init watchdog timer
	WDTCTL = WDTPW|WDTHOLD;               //Init watchdog timer

	while ((IFG1 & OFIFG) != 0) {
		// Wait for LF Osc to startup
		IFG1 &= ~OFIFG;
		delayus(100);
	} 


	// To use serial port on MSP430
	usart0Init(USART_BAUD_DIV(BAUD_RATE, USART0_BRCLK),
		   USART_BAUD_MOD(BAUD_RATE, USART0_BRCLK), 
		   USART_8N1, USART0_BRSEL); 

}
