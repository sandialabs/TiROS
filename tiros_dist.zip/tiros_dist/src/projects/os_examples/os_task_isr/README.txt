This very simple example demonstrates the usage of os api calls 
from an interrupt service routine. 

In this example, interrupts are raised under software control (software
interrupt).  
There are three tasks that are constantly waiting input.
1) eflag_task :  Waiting for an event flag to be set.
2) csem_task : Waiting for a counting semaphore.
3) msgq_task : Waiting to read on a message queue.

There is a notify_task that raises the interrupt periodically.

The isr_action (which is invoked by the ISR) performs 
different functions on alternate invocations.
On the first call, it releases the counting semaphore and sets an
event flag.
On the subsequent call, it sends a message on the message queue.


After the first ISR call, the eflag_task runs because it has higher
priority than csem_task, even though the counting semaphore was
released first.  Then the csem_task runs.

After the second ISR call, the msgq_task runs.






