
/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */

/* ************************************************** */
#  define TIROS_MAX_ISR_NESTING 2
#  define TIROS_MAX_PROCS    5
#  define TIROS_ENABLE_MUTEX  0
/* ************************************************** */


/* Configuration for Posix Port */
#  ifdef __POSIX_TIROS_PORT_H        
#  endif

/* Configuration for MSPGCC Port */
#  ifdef __MSP430GCC_TIROS_PORT_H
#  endif
#endif 
/* ---------------------------------------------------------------- */




