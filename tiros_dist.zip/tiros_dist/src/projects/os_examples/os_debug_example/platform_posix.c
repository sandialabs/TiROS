#include <stdio.h>
#include <tiros/tiros.h>

void platform_init(void)
{

}


void print_trtime(const trtime_t *t)
{
	printf("%ld:%ld", t->units, t->subunits);
}
