/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */
#  define TIROSINT_DATA_DEBUG
#  define TIROS_STK_CHECK
#  define TIROS_MAX_PROCS 8

/* Configuration for Posix Port */
#  ifdef __POSIX_TIROS_PORT_H        
#  endif

/* Configuration for MSPGCC Port */
#  ifdef __MSP430GCC_TIROS_PORT_H
#  endif

#endif 
/* ---------------------------------------------------------------- */


