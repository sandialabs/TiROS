This demonstrates debugging with TiROS. 
There are four tasks: t0, t2,  debug_task, idle_task.

The priorities are ordered as follows:
t0         : 0
debug_task : 1
t2         : 2
idle_task  : 4

The debug task retrieves the data and writes them out using the
putchar primitive.   Depending on the hardware port, this may be 
available on a serial port or standard output.

Capture this data to file (example: tst.dump) and run the  tiros_parse
program on it.

For example:
On Posix:  
./objects-release/os > tst.dump

Wait for at least 20 seconds (let the tst.dump file accumulate some
data).

Ctrl-C kill the program.

Run  ../..//tiros_parse/objects-release/tiros_parse -i ./tst.dump
(Make sure that tiros_parse has been compiled before this step).


See the debug output.


For other platforms, capture the output of the embedded program
(through serial port or other means) to file.

Run tiros_parse on the dump file.





