TiROS implements the Immediate Priority Ceiling Protocol (this is the
default) that can prevent priority  inversion and deadlock.



This demonstrates deadlock prevention using the priority ceiling protocol.



--------- This is what would happen if the Priority Inheritance
Protocol is used.  Since it has been deprecated, this cannot be run
anymore
---------------------------------------------------------------------

Lets first look at the effect if the Priority Ceiling Protocol is NOT
used.

Define TIROS_PRIO_INHERIT_PROTOCOl in the proj_config.h file.  Then the
priority inheritance protocol will be used instead of the priority
ceiling protocol.

The task priority is set as follows:
 Mutex M2 priority ceiling: 0
 Mutex M1 priority ceiling: 1
 J0 : 2
 J1 : 3
 idle_task : 4

Note that we have an idle task to allow the OS to run if the other two
tasks deadlock.



The output is as follows:




R       Running - HP
P       Achieved a P() on CS - HP
L       Locked mutex - HP
U       Unlocked mutex - HP
r       Running - LP
l       Locked mutex - LP
u       Unlocked mutex - LP
v       Did a V() on CS - LP
Task    Prio    Elev    Msg
--------------------------------------------------
J0 waiting for signal

T0x01   0x03    0x03    r     # J1 is running
J1 locking M1                 # J1 locks M1
T0x01   0x03    0x03    l
J1 signaling J0 to run
J0 got signal                 # J0 starts running
T0x00   0x02    0x02    P
J0 locking M2
T0x00   0x02    0x02    L     # J0 locked M2
J0 locking M1                 # J0 attempting lock on M1 but is blocked
T0x01   0x03    0x02    v     # J1 now runs with the inherited
                              # priority of J0

J1 locking M2                 # J1 tries to lock M2

Idle Task running             # DEADLOCK **********
Idle Task running
Idle Task running
Idle Task running
Idle Task running
Idle Task running
Idle Task running
------------------------------------------------------------------------






This is what happens when the Immediate Priority Ceiling Protocol is used.

==================================================
R       Running - HP
P       Achieved a P() on CS - HP
L       Locked mutex - HP
U       Unlocked mutex - HP
r       Running - LP
l       Locked mutex - LP
u       Unlocked mutex - LP
v       Did a V() on CS - LP
Task    Prio    Elev    Msg
--------------------------------------------------
J0 waiting for signal
T0x01   0x03    0x03    r     # J1 is running
J1 locking M1                 # J1 locks M1
T0x01   0x03    0x01    l     # Note that the effective priority of J1
                              # has been raised to the ceiling
			      # priority of M1

J1 signaling J0 to run        # J0 is allowed to run but it does not,
                              # since its priority is lower than the
			      # effective priority of J1

T0x01   0x03    0x01    v
J1 locking M2                 # J1 locks M2
T0x01   0x03    0x00    l     # J1's effective priority is raised to
                              # the ceiling priority of M2
J1 locked M2                  
J1 unlocking M2               # J1 unlocks M2
T0x01   0x03    0x00    u
J1 unlocking M1               # J1 unlocks M1 and reverts to its
                              # original priority

J0 got signal                 # J0 can now run
T0x00   0x02    0x02    P

J0 locking M2                 # J0 locks M2. Its effective priority                        
T0x00   0x02    0x00    L     # is the ceiling priority of M2

J0 locking M1                 # J0 attempts to lock M1.
                              # This attempt fails because
                              # the effective priority of J0 (due to
                              # M2) is higher than the ceiling
                              # priority of M1
                    
J0 lock error  0xFFFA
                              # ****** The protocol prevents the
                              # lock.  A lock error is returned
                              # but there is no deadlock.


T0x00   0x02    0x00    L
J0 unlocking M1
T0x00   0x02    0x00    U
J0 unlock error  0xFFE0
J0 unlocking M2
T0x00   0x02    0x02    U

J0 waiting for signal

