/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */
#  define TIROS_MAX_PROCS 4
#  define TIROS_ENABLE_MSGQ 0
#  define TIROS_ENABLE_EFLAG 0
/* Configuration for Posix Port */
#  ifdef __POSIX_TIROS_PORT_H        
#  endif

/* Configuration for MSP Port */
#  ifdef __MSP430GCC_TIROS_PORT_H
#  endif


#endif 
/* ---------------------------------------------------------------- */
