This project demonstrates the use of message queues.

TiROS message queues are statically allocated.

This project consists of three tasks T0, T1, T2 where prio(T0) >
prio(T1) > prio(T2).

The task with medium priority, T1, waits for messages on the message
queue.

The other two tasks post messages on the queue.
Sample annotated output is given below.
The message queue is intialized to have a size of 4.

T0 first sets resumes task T1.  If T1 has been waiting for the message
queue, it is explicitly awoken.  T1 when it runs again wakes up with ERR_RESUMED.

Task T0 sends a sequence of 7 messages rapidly.  Since it has higher
priority than Task T1, the queue fills up.  The final three messages
are not accepted.  After sending the 7 messages, Task T0 waits on a
counting semaphore.      Then Task T1 runs and consumes all the four
messages.  After this Task T2 sends a message which is immediately
consumed by T1 (because T1 has higher priority).  
T2 then releases the counting semaphore allowing T0 to run again.




==================================================
T0 resuming T1
T0: sending : A          # T0 sends the character A
T0: success              
T0: sending : B          # T0 sends the character B
T0: success
T0: sending : C          # T0 sends C
T0: success
T0: sending : D          # T0 sends D.  At this time the Q should be
                         # full.  

T0: success
T0: sending : E          # Q is full.
T0: Q full
T0: sending : F
T0: Q full
T0: sending : G
T0: Q full


T1: recvd message : A
T1: recvd message : B    # T1 consumes all four messages.
T1: recvd message : C
T1: recvd message : D


T2: sending : a          # T2 sends a message and is preempted
                         # immediately  by T1.
T1: recvd message : a    # T1 consumes the message.
T2: success              # T2 can then continue.


T0 resuming T1
T0: sending : H
T0: success
T0: sending : I
T0: success
T0: sending : J
T0: success
T0: sending : K
T0: success
T0: sending : L
T0: success
T0: sending : M
T0: Q full
T0: sending : N
T0: Q full
T1: ERR_Resumed

T1: recvd message : H
T1: recvd message : I
T1: recvd message : J
T1: recvd message : K
T1: recvd message : L
T2: sending : b
T1: recvd message : b
T2: success



