This example demonstrates the use of event flags.

There are four tasks in the system.
Tasks with ids 0, 1, 2, wait for an event.
Task with id 3, posts events.

The priorities correspond to the ids.


Task 0, 1 only listen to ALERT0 , ALERT1 respectively.
Task 2 listens to both ALERT0 and ALERT1, but it alternates the
options flag between O_EFLAG_AND and O_EFLAG_OR. 
Using O_EFLAG_AND requires both ALERT0 and ALERT1 to be set for Task2's wait
to succeed.  Using O_EFLAG_OR allows Task2's wait to succeed if either
ALERT0 or ALERT1 is set.



Here is the annotated output:

--------------------------------------------------
0x00 R: waitflag is 0x01
0x01 R: waitflag is 0x02
S setting ALERT0             # ALERT0 is being raised.
0x00 wait succeeded          # Task 0 was waiting on ALERT0 and wakes.
0x00 wait succeeded          # ALERT0 was not cleared and when Task 0
                             # checks it again, it is still set.
			     # Task 0 clears ALERT 0

S setting ALERT1            
0x01 wait succeeded          # Task 1 waits due to ALERT1
0x01 wait succeeded          # Task 1 checks again, ALERT1 is still
                             # set, Task 1 clears it.

S triggering ALERT0|ALERT1   # S triggers ALERT0, ALERT1
0x00 wait succeeded          
0x01 wait succeeded
0x02 wait succeeded
S setting ALERT0
0x00 wait succeeded
0x00 wait succeeded
0x02 wait succeeded
S setting ALERT1
0x01 wait succeeded
0x01 wait succeeded
S triggering ALERT0|ALERT1
0x00 wait succeeded
0x01 wait succeeded
0x02 wait succeeded
S setting ALERT0
0x00 wait succeeded
0x00 wait succeeded
0x02 wait succeeded
S setting ALERT1
0x01 wait succeeded
0x01 wait succeeded
