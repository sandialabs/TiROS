
/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */
#  define TIROS_MAX_PROCS 6
#endif 
/* ---------------------------------------------------------------- */
