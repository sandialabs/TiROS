#include <tiros/tiros.h>
#include <stdlib.h>
#include <signal.h>


void isr_action(void);

void platform_call_ISR(void)
{
	raise(SIGUSR1);
}

extern int halint_kernel_trap_flagged;
void platform_isr_upcall(int sig)
{
	OS_ISR_BEGIN();
	halint_kernel_trap_flagged = 0;
	isr_action();
	OS_ISR_END();
	if (halint_kernel_trap_flagged) {
		hal_ctxt_switch();
	}
}

void platform_init(void)
{
	struct sigaction siguser1_setup;
	sigset_t blockmask;
	sigemptyset( &blockmask);
	sigaddset(&blockmask, SIGALRM);
	sigaddset(&blockmask, SIGVTALRM);


	siguser1_setup.sa_handler = platform_isr_upcall;
	siguser1_setup.sa_mask = blockmask;
	siguser1_setup.sa_flags = 0;
	sigaction(SIGUSR1, &siguser1_setup, NULL);

}
