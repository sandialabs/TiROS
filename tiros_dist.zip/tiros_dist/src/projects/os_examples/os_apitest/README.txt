This contrived example program exercises 100% code coverage of 
tiros.c.   It uses every api call and every return code is exercised.




