

/* ---------------------------------------------------------------- */
#if  defined(LOCAL_CONFIG) || defined(TIROS_USER_CONFIG)
#  define NUM_WRKR_TASKS	       4
#  define NUM_PREDEFINED_TASKS   (NUM_WRKR_TASKS + 2)
#endif
/* ---------------------------------------------------------------- */


/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */
#  define TIROS_ALLOW_SLEEP_W_MUTEX 1
#  define TIROS_C90_COMPATIBLE  1
#  define TEST_ISR_BASED_CODE 
#  define TIROS_MAX_ISR_NESTING 2


/* ************************************************** */
#  define TIROS_MAX_PROCS   (NUM_PREDEFINED_TASKS + 3)
#  define TIROS_MAX_MUTEXES 2
#  define TIROS_CSEMVAL_MAX 10
/* ************************************************** */


/* Configuration for Posix Port */
#  ifdef __POSIX_TIROS_PORT_H        
#  endif

/* Configuration for MSPGCC Port */
#  ifdef __MSP430GCC_TIROS_PORT_H
#  endif
#endif 
/* ---------------------------------------------------------------- */





