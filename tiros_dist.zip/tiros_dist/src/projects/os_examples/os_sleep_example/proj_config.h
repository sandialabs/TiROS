
/* ---------------------------------------------------------------- */
#ifdef TIROS_USER_CONFIG                /* Tiros user configuration */

#  define TIROS_ENABLE_MSGQ 0
#  define TIROS_ENABLE_EFLAG 0
#  define TIROS_MAX_PROCS 8


/* Configuration for Posix Port */
#  ifdef __POSIX_TIROS_PORT_H        
#    define PORT_TIMER_TYPE 1
#    define OS_DEBUG
#  endif

/* Configuration for MSPGCC Port */
#  ifdef __MSP430GCC_TIROS_PORT_H
#    define TRPORT_MSP_OSTIMER B
#  endif
#endif 
/* ---------------------------------------------------------------- */



