#include <tiros/tiros.h>

void platform_init(void)
{

}

