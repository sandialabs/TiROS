This program can parse the debug output from tiros and display it in a
meaningful manner.

An example debug output file is given in this directory tst.dump


To examine it, run ./objects-release/tiros_parse -i tst.dump


This tst.dump file was created by running the example in 
src/projects/os_examples/os_debug_example  for the posix platform and
directing its output to tst.dump.



Note: The displayed output uses wide columns, so enlarge your terminal
to accommodate the width of a single row of output.


