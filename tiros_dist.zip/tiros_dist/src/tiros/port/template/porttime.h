#ifndef _GENERIC_TRTIME_H
#define _GENERIC_TRTIME_H

/* Author: Ratish J. Punnoose, 2006
 * This file is part of TiROS, the Tickless Real-Time Operating System.
 * Copyright(c) 2006, 2007: Ratish J. Punnoose.
 * Copyright(c) 2006 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
 * certain rights in this software. 
 * 
 * TiROS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 or (at your option) any later version.
 *
 * TiROS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with TiROS; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
 *
 * As a special exception, if other files instantiate templates or use macros
 * or inline functions from this file, or you compile this file and link it
 * with other works to produce a work based on this file, this file does not
 * by itself cause the resulting work to be covered by the GNU General Public
 * License. However the source code for this file must still be made available
 * in accordance with section (3) of the GNU General Public License.
 *
 * This exception does not invalidate any other reasons why a work based on
 * this file might be covered by the GNU General Public License.
 *
 */


/* This is the max value of subunits */
#define SUBUNITS_MAX  1000000000


LT_INLINE uint32_t  trtime_to_secs(const trtime_t *lt)
{
	return lt->units;
}

LT_INLINE void  secs_to_trtime(uint32_t seconds, trtime_t *lt)
{
	lt->units = seconds;
	return;
}


/** \brief Time subtraction
 * @param x  Time1
 * @param y  Time2
 * @param [out] res  Time1 - Time 2 */
LT_INLINE void time_sub(const trtime_t * x, const trtime_t * y, trtime_t *res)
{
	res->units = x->units - y->units;

	if (x->subunits >= y->subunits)
		res->subunits = x->subunits - y->subunits;
	else { 
		res->subunits = SUBUNITS_MAX + x->subunits - y->subunits;
		res->units--;
	}

}

/** \brief Time addition
 * @param x  Time1
 * @param y  Time2
 * @param [out] res  Time1 + Time 2 */
LT_INLINE void time_add(const trtime_t * x, const trtime_t * y, trtime_t *res)
{
	res->units = x->units + y->units;
	res->subunits = x->subunits + y->subunits;

	if (res->subunits >= SUBUNITS_MAX) {
		res->units++;
		res->subunits = res->subunits - SUBUNITS_MAX;
	}
}

/** \brief Time comparison
 * @param t1  Time1
 * @param t2  Time2
 * @Return   (-1,0,1) depending on whether t1 < t2, t1==t2, t1 > t2  */
LT_INLINE int time_compare(const trtime_t * t1, const trtime_t * t2)
{
	int res;
	if (t1->units < t2->units) {
		res = -1;
	} else if (t1->units > t2->units){
		res = 1;
	} else 	{// Both equal.
		if (t1->subunits < t2->subunits)
			res = -1;
		else if (t1->subunits > t2->subunits)
			res = 1;
		else
			res = 0;

	}
	return res;
}


/** @brief Time comparison (simple less than )
 * @param t1  Time1
 * @param t2  Time2
 * @Return   (1,0) depending on whether t1 ?< t2 */
LT_INLINE int time_lessthan(const trtime_t * t1, const trtime_t * t2)
{
	int res = 0;
	if (t1->units < t2->units) {
		res = 1;
	}else if (t1->units == t2->units){
		if (t1->subunits < t2->subunits)
			res = 1;
	} 

	return res;
}


#endif
