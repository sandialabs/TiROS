
#include "../../tr_int.h"



/* Author: Ratish J. Punnoose, 2006
 * This file is part of TiROS, the Tickless Real-Time Operating System.
 * Copyright(c) 2006, 2007: Ratish J. Punnoose.
 * Copyright(c) 2006 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
 * certain rights in this software. 
 * 
 * TiROS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 or (at your option) any later version.
 *
 * TiROS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with TiROS; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
 *
 * As a special exception, if other files instantiate templates or use macros
 * or inline functions from this file, or you compile this file and link it
 * with other works to produce a work based on this file, this file does not
 * by itself cause the resulting work to be covered by the GNU General Public
 * License. However the source code for this file must still be made available
 * in accordance with section (3) of the GNU General Public License.
 *
 * This exception does not invalidate any other reasons why a work based on
 * this file might be covered by the GNU General Public License.
 *
 */



/** \name timer setup functions
 * @{ */

static trtime_t hal_os_time;
static trtime_t hal_next_alarm_time;

osstkptr_t kernel_trap_ctxt_ptr;

/* This macro setup, allows us to use either Timer A or Timer B. Due
 * to the bizarre rules of C preprocessor stringification, we have 
 * to use a double macro call, as a single call does not prescan
 * (evaluate) the macro argument */ 

#define MC_CONT  MC_2
#define MC_STOP  MC_0
#define TASSEL_ACLK   TASSEL_1
#define TBSSEL_ACLK   TBSSEL_1
#define TxCLR  0x0004


/* Eg. TIMERA0_VECTOR */
#define xMSP_TIMERxy_VECTOR(t, num) TIMER ## t ## num ## _VECTOR
#define MSP_TIMERxy_VECTOR(a,b) xMSP_TIMERxy_VECTOR(a,b)

/* Eg.  TACCR0 */
#define xMSP_TxCCRy(t, num) T ## t ## CCR ## num
#define MSP_TxCCRy(t, num)  xMSP_TxCCRy(t, num)

/* Eg.  TACTL */
#define xMSP_TxCTL(t) T ## t ## CTL
#define MSP_TxCTL(t)  xMSP_TxCTL(t)

/* Eg. TASSEL_ACLK */
#define xMSP_TxSSEL_ACLK(t) T ## t ## SSEL_ACLK
#define MSP_TxSSEL_ACLK(t)  xMSP_TxSSEL_ACLK(t)

/* Eg. TAIE */
#define xMSP_TxIE(t)  T ## t ## IE
#define MSP_TxIE(t)   xMSP_TxIE(t)

/* Eg. TACCTL0 */
#define xMSP_TxCCTLy(t,n)  T ## t ## CCTL ## n
#define MSP_TxCCTLy(t,n) xMSP_TxCCTLy(t,n)

/* Eg. TAR */
#define xMSP_TxR(t)  T ## t ## R
#define MSP_TxR(t)   xMSP_TxR(t)


#define TIMERB_OVERFLOW   0x0E
#define TIMERA_OVERFLOW   0x0A

#define TIMERA_CCR1_CCIFG  0x02
#define TIMERB_CCR1_CCIFG  0x02

#define TxCLR  0x0004


/* Eg. TIMERA_OVERFLOW */
#define xMSPTIMER_OVERFLOW(t) TIMER ## t ## _OVERFLOW
#define MSPTIMER_OVERFLOW(t)  xMSPTIMER_OVERFLOW(t)

/* Eg. TIMERA_CCR1_CCIFG */
#define xMSPTIMER_CCR1_CCIFG(t) TIMER ## t ## _CCR1_CCIFG
#define MSPTIMER_CCR1_CCIFG(t)  xMSPTIMER_CCR1_CCIFG(t)


/** Set the timer compare
 * @param t Timer value at which there should be an interrupt */
static inline void halint_set_timer_compare(uint16_t t)
{
	/* Set the register and enable timer */
	MSP_TxCCRy(TRPORT_MSP_OSTIMER, 0) = t;

	/* Reset TCCTLx register to SCS, CCIE, */
	MSP_TxCCTLy(TRPORT_MSP_OSTIMER,0) =  SCS | CCIE;
}


/** Disable the compare function */
static inline  void halint_disable_timer_compare(void) 
{ 
	/* Disable the compare register interrupt */
	MSP_TxCCTLy(TRPORT_MSP_OSTIMER,0) &= ~CCIE;
}

/** Get the timer value
 * @return Timer value */
static inline uint16_t  halint_get_timer_value(void) 
{ 
	return MSP_TxR(TRPORT_MSP_OSTIMER);
}


/** Update the timer subunits from the hal timer value.
 *  This also checks for counter rollover.
 * @return 1 if a timer rollover occurred, 0 otherwise */
static int halint_update_timer_subunits(void)
{
 	/* To avoid a possible race condition, we must also check to
	 * see if the counter has rolled over
	 *
	 *  The race condition can occur as follows:
	 *  os_time_get() is called.
	 *  interrupts are disabled.
	 *  counter overflows.
	 *
	 * halint_get_timer_value() is called
	 * It returns overflowed counter value.
	 * Since interrupts are disabled, the isr_counter_rollover has
	 * not yet been invoked.  So subunits is good, but units is not.
	 *  
	 */

	uint16_t timer_overflow;
	hal_os_time.subunits = halint_get_timer_value();

	timer_overflow = MSP_TxCTL(TRPORT_MSP_OSTIMER) & 0x0001;
	if (timer_overflow) {
		/* Clear the interrupt flag */
		MSP_TxCTL(TRPORT_MSP_OSTIMER) &=  ~0x0001;
		/* Increment the time units */
		hal_os_time.units += 1;
		/* Check subunits again, since the rollover may have happened
		 * after the last read, */
		hal_os_time.subunits = halint_get_timer_value();
	}
	return timer_overflow;
}

/** After a timer rollover, process alarms
 * @return 1 if a context switch is necessary, 0 otherwise  */
static int halint_re_alarm_after_rollover(void)
{
	/* If units match */
	if (hal_next_alarm_time.units == hal_os_time.units) {
		/* If subunits are within response time*/
		if (hal_next_alarm_time.subunits <    PORT_WAKEUP_RESPONSE_SUBUNITS) {
			if (osint_alarm_reached(&hal_os_time)) {
				return 1;
			}
		} else { /* Units match but subunits are later.  Set
			  * the alarm for later */
			halint_set_timer_compare(hal_next_alarm_time.subunits);
		}
	}
	return 0;
}





/** Set and enable the timer compare
 * @param subunits  Value for timer compare */
void  hal_alarm_set(const trtime_t *lt) 
{ 
	if (lt) {
		hal_next_alarm_time.units = lt->units;
		hal_next_alarm_time.subunits   = lt->subunits;
		if (hal_next_alarm_time.units == hal_os_time.units) {
			halint_set_timer_compare(hal_next_alarm_time.subunits);
		}


	} else {
		hal_next_alarm_time.units = ~0;
		hal_next_alarm_time.subunits   = ~0;
		halint_disable_timer_compare();
	}
	

}


/** Setup the timer
 *
 * This does the equivalent of:
 * T[A|B]CCR0 = 0xFFFF;
 * T[A|B]CTL  = T[A|B]SSEL_ACLK | T[A|B]IE  | MC_CONT | T[A|B]CLR
 * Setup Compare register using T[A|B]CCTL0
*/
void halint_timer_setup(void)
{
	hal_os_time.units = 0;
	hal_os_time.subunits = 0;
	MSP_TxCCRy(TRPORT_MSP_OSTIMER, 0) = 0xFFFF;
	MSP_TxCCTLy(TRPORT_MSP_OSTIMER,0) = SCS;

	MSP_TxCTL(TRPORT_MSP_OSTIMER) = MSP_TxSSEL_ACLK(TRPORT_MSP_OSTIMER) |
		MSP_TxIE(TRPORT_MSP_OSTIMER) | MC_CONT | TxCLR;
}


void halint_setup_kernel_trap(void);

void hal_init(void)
{
	halint_timer_setup();
	halint_setup_kernel_trap();
	
}

void hal_time_get(trtime_t *t)
{
	uint16_t timer_overflow;
	t->subunits = halint_get_timer_value();
	
	timer_overflow = MSP_TxCTL(TRPORT_MSP_OSTIMER) & 0x0001;
	if (timer_overflow) {
		/* Don't clear interrupt flag.  The interrupt routine
		 * will be triggered later */
		t->subunits = halint_get_timer_value();

		/* Due to overflow, add one to units */
		t->units =  hal_os_time.units + 1;
	} else {
		t->units = hal_os_time.units;
	}
}


int hal_time_set(const trtime_t *t)
{
	/* Stop the currently running timer */
	MSP_TxCTL(TRPORT_MSP_OSTIMER) = MSP_TxSSEL_ACLK(TRPORT_MSP_OSTIMER) |
		MSP_TxIE(TRPORT_MSP_OSTIMER) | MC_STOP;	
	/* Set the subunits value for the timer */
	MSP_TxR(TRPORT_MSP_OSTIMER) = t->subunits;

	/* Restart the timer */
	MSP_TxCTL(TRPORT_MSP_OSTIMER) = MSP_TxSSEL_ACLK(TRPORT_MSP_OSTIMER) |
		MSP_TxIE(TRPORT_MSP_OSTIMER) | MC_CONT;	
	hal_os_time.subunits = t->subunits;
	hal_os_time.units = t->units;
	/* What do we do about alarms ? 
	* We don't have to worry about alarms that have expired as a
	result of this time change.  The OS already takes care of
	that.  We also don't have to worry about alarms that are not
	present in this time supersec.  The time change doesn't affect
	them.  What we have to deal with is an alarm time that is in
	the current supersec, but later than t->subunits */
	halint_disable_timer_compare();
	if (hal_next_alarm_time.units == hal_os_time.units) {
		if (hal_next_alarm_time.units > hal_os_time.subunits)
			halint_set_timer_compare(hal_next_alarm_time.subunits);
		
	}
	

	/* This port can set time */
	return 1;
}

/** @} End timer functions */








/* The default SR only has the interrupt enable set. */
#define OS_DEF_SR	0x0008


/* Initialize the stack with this value */
#define MSP430_STACK_INIT_WORD           0x3C57

osstkptr_t hal_stk_init(osword_t *stk, osword_t stacksize, osfnptr_t pc,
		     osptr_t init_arg) 
{
	/* MSP430 stacks grows from high memory to low memory */
	osword_t *s = stk + stacksize-1;
	osword_t *stk_val;

	*s-- = (osword_t)pc; 	/*  R0 = Program Counter */
	/* R1 = stack Pointer. */
	*s-- = OS_DEF_SR; /* R2 = Status Register.  */
	/* R3 =  Constant generator. */
	*s-- = 0;  /* R4  */
	*s-- = 0;  /* R5  */
	*s-- = 0;  /* R6  */
	*s-- = 0;  /* R7  */
	*s-- = 0;  /* R8  */
	*s-- = 0;  /* R9  */
	*s-- = 0;  /* R10 */
	*s-- = 0;  /* R11 */
	*s-- = (osword_t)init_arg;  /* R12 contains the argument */
	*s-- = 0;  /* R13 */
	*s-- = 0;  /* R14 */
	*s =  0;   /* R15  */

	for (stk_val = (osword_t*)stk; stk_val < s;  stk_val++) 
		*stk_val = MSP430_STACK_INIT_WORD;


	return s;
}







#ifdef TIROSINT_DATA_DEBUG
/** Compute the program counter, from the stored context (stack
 * pointer)
 * This function is used for debugging.  Implement this by extracting
 * the program counter out of the stack pointer if possible.
 *
 * @param ctxt_ptr  The pointer to the context of the task
 * @return The program counter */
osptrword_t hal_pc_from_ctxt(osstkptr_t ctxt_ptr)
{
	/* The program counter register is 13 words up from the stack
	 * pointer */
	return (osptrword_t) *(ctxt_ptr + 13);
}


#ifdef TIROS_STK_CHECK

osword_t hal_stkusage_curr(osstkptr_t ctxt_ptr, osstkptr_t base_stkptr,
			   osword_t stksize)
{
	/* ctst_ptr s the stack pointer */
	
	/* The free stack is just the difference between this and the
	   allocated */

	return ( stksize - ((osword_t*)ctxt_ptr - (osword_t*)base_stkptr));
}

osword_t hal_stkusage_max(osstkptr_t ctxt_ptr, osstkptr_t base_stkptr,
			   osword_t stksize)
{
	osword_t rc;
	osword_t *base_stk = (osword_t*)base_stkptr;

	/* Measure free stack */
	for(rc = 0 ; rc < (stksize - MSP430_INIT_STACK_OCCUPANCY ); rc++) {
		if (*base_stk != MSP430_STACK_INIT_WORD)
			break;
		base_stk++;
	}

	/* Compute occupied stack */
	return (stksize - rc);
	
}

#endif /*TIROS_STK_CHECK */


#endif /* TIROSINT_DATA_DEBUG */







/** HAL Internal macro used to save the registers.
 * This can be called from an interrupt function. It does not save the
 * status register.  If being called from non-interrupt code, the
 * status register should be saved before calling this function */
#define HALINT_CTXT_SAVE() \
		"push   r4    \n\t"	\
		"push   r5    \n\t"	\
		"push   r6    \n\t"	\
		"push   r7    \n\t"	\
		"push   r8    \n\t"	\
		"push   r9    \n\t"	\
		"push   r10   \n\t"	\
		"push   r11   \n\t"	\
		"push   r12   \n\t"	\
		"push   r13   \n\t"	\
		"push   r14   \n\t"	\
		"push   r15   \n\t"	\
		"mov.w  r1, r12 \n\t"	


/* When this macro is called, the Program Counter is
 * already stored on the stack. 
 * Why-> This is the first invocation within hal_ctxt_switch().
 * When hal_ctxt_switch() is called, the PC is stored on the stack, so
 * that the program from continue from that point when the function ends.
 * The difference from an ISR invocation, is that the status register is not stored. */

#if (__CORE__ == __430__ )
#  define HALINT_TASK_CTXT_SAVE() \
		"push r2	\n\t" 	\
		HALINT_CTXT_SAVE()
#elif (	__CORE__ == __430X__)
#  if (__REGISTER_MODEL__ == __REGISTER_MODEL_REG16__)
#    define HALINT_TASK_CTXT_SAVE() \
                "pop  r12       \n\t"   \
                "pop  r13       \n\t"   \
		"push r12       \n\t"   \
		"push r2	\n\t" 	\
		HALINT_CTXT_SAVE()
#  else
#    error "Only Small memory model on 430x (16 bit registers) supported"
#  endif

#else
#  error "Unsupported MSP430 Core"
#endif



#define HALINT_CTXT_LOAD()	\
		"mov.w	r12, r1	\n\t"	\
		"pop	r15	\n\t"	\
		"pop	r14	\n\t"	\
		"pop	r13	\n\t"	\
		"pop	r12	\n\t"	\
		"pop	r11	\n\t"	\
		"pop	r10	\n\t"	\
		"pop	r9	\n\t"	\
		"pop	r8	\n\t"	\
		"pop	r7	\n\t"	\
		"pop	r6	\n\t"	\
		"pop	r5	\n\t"	\
		"pop	r4	\n\t"	\
		"reti		\n\t"	



osstkptr_t osint_taskswitcher_dummy(osstkptr_t old_ctxtptr)
{
	return osint_taskswitcher(old_ctxtptr);
}


/** Context switch from user level (non-ISR)
 *  This function is called from within an OS call, to switch the
 *  running process.  It also provides a return value. This is a
 *  pseudo return-value.  This function does not actually determine
 *  the value returned.  The return value is set by hal_retval_set
 *  which is often invoked when waking the process up from a blocked
 *  state.   The __task keyword in iar do not save any registers.
 * @return  Return value.  */
__task osstkptr_t hal_ctxt_switch(void)
{

#if (__CORE__ == __430__ )
	__asm ( 	HALINT_TASK_CTXT_SAVE()
		"call #osint_taskswitcher	\n"
		HALINT_CTXT_LOAD()
		);
#elif (	__CORE__ == __430X__)
	__asm ( 	HALINT_TASK_CTXT_SAVE()
		"calla #osint_taskswitcher	\n"
		HALINT_CTXT_LOAD()
		);
#else
#  error "Unsupported MSP430 Core"
#endif
	/* This is just to eliminate compiler warnings.  In theory,
	 * program execution flow never reaches this point because
	 * hal_ctxt_load performs a return from interrupt.  This
	 * tricks the calling process into looking at the return value
	 * in one of its registers.  This return value would have been
	 * set earlier by hal_retval_set. */
	return 0; 
}



/** Load the given context
 * @param ctxt_ptr   Pointer to task context */
__task  void hal_ctxt_load(osstkptr_t ctxt_ptr) 
{
	/* In this port, the stack pointer provides the context.
	 * R12 is used for passing arguments and returning values by
	 * IAR */
	asm ( "mov.w r12, r1 \n"
	      "pop	r15	\n"
	      "pop	r14	\n"
	      "pop	r13	\n"
	      "pop	r12	\n"
	      "pop	r11	\n"
	      "pop	r10	\n"
	      "pop	r9	\n"
	      "pop	r8	\n"
	      "pop	r7	\n"
	      "pop	r6	\n"
	      "pop	r5	\n"
	      "pop	r4	\n"
	      "reti		\n"
		);


} 












/* If the Kernel Trap method is not used, then the ISRs have to save
 * the context of the running task upon entry and load the context of
 * the next task on exit */
int halint_kernel_trap_flagged;
void halint_setup_kernel_trap(void){ }


















#ifndef USER_DEFINED_TIMER_TRAP
/** This is the ISR for counter rollover, on the MSP430 port, by
 * default it is the Timer A source as it is implemented in all
 * MSP430x1xx devices */


#pragma vector=MSP_TIMERxy_VECTOR(TRPORT_MSP_OSTIMER,1)
__raw __interrupt void isr_counter_rollover(void)
{
	HALINT_ISR_ENTRY();

	/* This can also be done using the TAIV|TBIV register.
	 * However, accessing that register automatically resets the
	 * highest priority outstanding interrupt.   There may be
	 * higher priority interrupts than what this handler can
	 * support.  So since, we are only handling a subset of
	 * interrupts in this handler, it is best to not touch
	 * TAIV|TBIV.*/ 

	
	/* Update subunits and check for timer rollover */
	if (halint_update_timer_subunits()) {
		/* If timer has rolled over */
		if (halint_re_alarm_after_rollover() ) {
			OS_KERNEL_TRAP();
		}
	}
	

	HALINT_ISR_EXIT();
}



/** Interrupt function for a compare match */
#pragma vector=MSP_TIMERxy_VECTOR(TRPORT_MSP_OSTIMER,0)
__raw __interrupt void isr_compare_match(void) 
{
	HALINT_ISR_ENTRY();
	/* We are not enabling interrupts, and we have explicit
	 * knowledge of whether a context switch is required, so we
	 * don't use OS_ISR_BEGIN and OS_ISR_END. */
	halint_disable_timer_compare();

	/* Update subunits */
	halint_update_timer_subunits();

	if (  osint_alarm_reached(&hal_os_time ) )
		OS_KERNEL_TRAP();
	HALINT_ISR_EXIT();
}









#endif /* USER_DEFINED_TIMER_TRAP */






