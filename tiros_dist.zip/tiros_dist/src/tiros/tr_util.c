/* Author: Ratish J. Punnoose, 2006
 * This file is part of TiROS, the Tickless Real-Time Operating System.
 * Copyright(c) 2006, 2007: Ratish J. Punnoose.
 * Copyright(c) 2006 Sandia Corporation. Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
 * certain rights in this software. 
 * 
 * TiROS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 or (at your option) any later version.
 *
 * TiROS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with TiROS; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
 *
 * As a special exception, if other files instantiate templates or use macros
 * or inline functions from this file, or you compile this file and link it
 * with other works to produce a work based on this file, this file does not
 * by itself cause the resulting work to be covered by the GNU General Public
 * License. However the source code for this file must still be made available
 * in accordance with section (3) of the GNU General Public License.
 *
 * This exception does not invalidate any other reasons why a work based on
 * this file might be covered by the GNU General Public License.
 *
 */


#include "tr_int.h"
#include <util.h>
#include <tiros/tr_util.h>




void print_trtime(trtime_t const *t)
{
	uint32_t sec = t->units;
	uint32_t subunits = t->subunits;
	putchar('0'); putchar('x');
	puthexint(sec, 4);
	putchar(':');
	puthexint(subunits, sizeof(t->subunits));
}



#if (TIROS_DEBUG_LEVEL > 0)

void print_TCBarray(tid_t run_task, tid_t rdy_task, tid_t wt_task,
		    struct TCB* TCBarray,
		    tid_t * TCB_meta, tid_t *lklist_meta)
{
	int i = 0;
	struct TCB *t;
#ifdef TIROS_STK_CHECK
	putstring("\nInd\tList\tstack\tprio\teprio\tflags\tmut\tbase_ptr\tstksize\tstk_cur\tstk_max\ttimeout   run="); 
#else
	putstring("\nInd\tList\tstack\tprio\teprio\tflags\tmut\ttimeout   run="); 
#endif
	puthexchar(run_task ); 
	putstring("  rdy="); 
	puthexchar(rdy_task);
	putstring("  wait=");
	puthexchar(wt_task);
	putchar('\n');

	for (i=0; i< TIROS_MAX_PROCS; i++) {
		t = &TCBarray[i];
		puthexchar((uint8_t) i); putchar('\t'); /*Ind */
		puthexchar(TCB_meta[i]); putchar('\t'); /*list */
		putchar('0'); putchar('x'); 
		puthexint((osword_t)t->ctxt_ptr, sizeof(osword_t));
		putchar('\t'); /*stack */
		
		puthexchar(t->priority); putchar('\t'); /*prio */
		puthexchar(t->eff_priority); putchar('\t'); /*eprio */
		puthexchar(t->flags); putchar('\t');        /*flags */
		puthexchar(t->num_mutexes); putchar('\t'); /* num_mutexes */

#ifdef TIROS_STK_CHECK

		/* Base stack ptr */
		putchar('0'); putchar('x');
		puthexint((osword_t)t->base_stk_ptr, sizeof(osword_t));
		putchar('\t');

		/* Stack size */
		putchar('0'); putchar('x');
		puthexint((osword_t)t->stksize, sizeof(osword_t));
		putchar('\t');

		/* Curr stack */
		putchar('0'); putchar('x');
		puthexint((osword_t)hal_stkusage_curr(t->ctxt_ptr,
						      t->base_stk_ptr, t->stksize) , sizeof(osword_t));
		putchar('\t');
		/* Max stack */
		putchar('0'); putchar('x');
		puthexint((osword_t)hal_stkusage_max(t->ctxt_ptr,
						     t->base_stk_ptr, t->stksize) , sizeof(osword_t));

#endif

		putchar('\t');
		print_trtime( &TCBarray[i].timeout);
		putchar('\n');
	}

	putstring("--END -TCBarray----\n");
} 


#endif
